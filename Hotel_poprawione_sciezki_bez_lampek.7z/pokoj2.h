#ifndef POKOJ2_H
#define POKOJ2_H

#include <QDialog>

namespace Ui {
class Pokoj2;
}

class Pokoj2 : public QDialog
{
    Q_OBJECT

public:
    explicit Pokoj2(QWidget *parent = 0);
    ~Pokoj2();
private slots:
    void on_wlaczTelewizor_clicked();

    void on_wylacztelewizor_clicked();

    void on_wlaczSwiatlo_clicked();

    void on_wylaczSwiatlo_clicked();

    void on_wlaczSwiatloLazienka_clicked();

    void on_otworzOkno_clicked();

    void on_wlaczGrzaniePokoj_clicked();

    void on_wlaczGrzanieLazienka_clicked();

    void on_zamknijDrzwi_clicked();

    void on_wlaczMuzyka_clicked();

    void on_wylaczSwiatloLazienka_clicked();

    void on_zamknijOkno_clicked();

    void on_wylaczGrzaniePokoj_clicked();

    void on_wylaczGrzanieLazienka_clicked();

    void on_otworzDrzwi_clicked();

    void on_wylaczMuzyka_clicked();


private:
    Ui::Pokoj2 *ui;
};

#endif // POKOJ2_H
