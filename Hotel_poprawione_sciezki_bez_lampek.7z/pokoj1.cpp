#include "pokoj1.h"
#include "ui_pokoj1.h"
#include <QPixmap>


Pokoj1::Pokoj1(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Pokoj1)
{
    ui->setupUi(this);
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R10_kontury_36-45.png");
    ui->pokoj->setPixmap(pix);

    setWindowTitle("Pokój 1");

}

Pokoj1::~Pokoj1()
{
    delete ui;

}



void Pokoj1::on_pushButton_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R07_telewizor_46-139.png");
    ui->telewizor->setPixmap(pix);
}

void Pokoj1::on_pushButton_2_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R01_swiatloPokoj_45-54.png");
    ui->swiatlo->setPixmap(pix);
}

void Pokoj1::on_pushButton_3_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R02_swiatloLazienka_175-374.png");
    ui->swiatloLazienka->setPixmap(pix);
}

void Pokoj1::on_pushButton_4_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R04_okno_136-46.png");
    ui->okno->setPixmap(pix);
}

void Pokoj1::on_pushButton_5_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R05_kaloryferPokoj_140-55.png");
    ui->kaloryferPokoj->setPixmap(pix);
}

void Pokoj1::on_pushButton_6_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R06_kaloryferLazienka_176-375.png");
    ui->kaloryferLazienka->setPixmap(pix);
}

void Pokoj1::on_pushButton_7_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R03_drzwi_66-556.png");
    ui->drzwi->setPixmap(pix);
}

void Pokoj1::on_pushButton_8_clicked()
{
    QPixmap pix("");
    ui->swiatloLazienka->setPixmap(pix);

}
//---------------------------------------------------------------------------------------------------


void Pokoj1::on_pushButton_9_clicked()
{
    QPixmap pix("");
    ui->telewizor->setPixmap(pix);
}

void Pokoj1::on_pushButton_10_clicked()
{
    QPixmap pix("");
    ui->swiatlo->setPixmap(pix);
}

void Pokoj1::on_pushButton_11_clicked()
{
    QPixmap pix("");
    ui->okno->setPixmap(pix);
}

void Pokoj1::on_pushButton_12_clicked()
{
    QPixmap pix("");
    ui->kaloryferPokoj->setPixmap(pix);
}

void Pokoj1::on_pushButton_13_clicked()
{
    QPixmap pix("");
    ui->kaloryferLazienka->setPixmap(pix);
}

void Pokoj1::on_pushButton_14_clicked()
{
    QPixmap pix("");
    ui->drzwi->setPixmap(pix);
}

void Pokoj1::on_pushButton_16_clicked()
{
    QPixmap pix("");
    ui->swiatloLazienka->setPixmap(pix);
}


