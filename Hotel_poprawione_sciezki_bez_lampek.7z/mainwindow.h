#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "pokoj1.h"
#include "pokoj2.h"
#include "pokoj3.h"
#include "pokoj4.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_comboBox_currentIndexChanged(int index);

    void on_wyswietl_pokoj_clicked();

    void on_pushButton_clicked();

signals:


    // Sygnały dla pokoju 1:

         void on_wlSwiatloLazienka_clicked();
         void on_wylSwiatloLazienka_clicked();

         void on_wlaczTelewizor_clicked();
         void on_wylaczTelewizor_clicked();

         void on_wlOgrzewanie_clicked();
         void on_wylOgrzewanie_clicked();



         void on_drzwiOtworz_clicked();
         void on_drzwiZamknij_clicked();

         void on_wlSwiatloGlowne_clicked();
         void on_wylSwiatloGlowne_clicked();


         void on_wlMuzyka_clicked();
         void on_wylMuzyka_clicked();

         void on_oknoOtworz_clicked();
         void on_oknoZamknij_clicked();
    //-----------------------


         // Sygnały dla pokoju 2:

              void on_wlSwiatloLazienka_2_clicked();
              void on_wylSwiatloLazienka_2_clicked();

              void on_wlaczTelewizor_2_clicked();
              void on_wylaczTelewizor_2_clicked();

              void on_wlOgrzewanie_2_clicked();
              void on_wylOgrzewanie_2_clicked();



              void on_drzwiOtworz_2_clicked();
              void on_drzwiZamknij_2_clicked();

              void on_wlSwiatloGlowne_2_clicked();
              void on_wylSwiatloGlowne_2_clicked();


              void on_wlMuzyka_2_clicked();
              void on_wylMuzyka_2_clicked();

              void on_oknoOtworz_2_clicked();
              void on_zamknijOkno_2_clicked();
         //-----------------------

               // Sygnały dla pokoju 3:

                   void on_wlSwiatloLazienka_3_clicked();
                   void on_wylSwiatloLazienka_3_clicked();

                   void on_wlaczTelewizor_3_clicked();
                   void on_wylaczTelewizor_3_clicked();

                   void on_wlOgrzewanie_3_clicked();
                   void on_wylOgrzewanie_3_clicked();



                   void on_drzwiOtworz_3_clicked();
                   void on_drzwiZamknij_3_clicked();

                   void on_wlSwiatloGlowne_3_clicked();
                   void on_wylSwiatloGlowne_3_clicked();


                   void on_wlMuzyka_3_clicked();
                   void on_wylMuzyka_3_clicked();

                   void on_otworzOkno_3_clicked();
                   void on_zamknijOkno_3_clicked();
              //-----------------------

                   // Sygnały dla pokoju 4:

                       void on_wlSwiatloLazienka_4_clicked();
                       void on_wylSwiatloLazienka_4_clicked();

                       void on_wlaczTelewizor_4_clicked();
                       void on_wylacztelewizor_4_clicked();

                       void on_wlOgrzewanie_4_clicked();
                       void on_wylOgrzewanie_4_clicked();



                       void on_drzwiOtworz_4_clicked();
                       void on_drzwiZamknij_4_clicked();

                       void on_wlSwiatloGlowne_4_clicked();
                       void on_wylSwiatloGlowne_4_clicked();


                       void on_wlMuzyka_4_clicked();
                       void on_wylMuzyka_4_clicked();

                       void on_otworzOkno_4_clicked();
                       void on_zamknijOkno_4_clicked();
                  //-----------------------



private:
    Ui::MainWindow *ui;
    Pokoj1* nowy1;
    Pokoj2* nowy2;
    Pokoj3* nowy3;
    Pokoj4* nowy4;
};

#endif // MAINWINDOW_H
