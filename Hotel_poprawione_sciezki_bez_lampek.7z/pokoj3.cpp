#include "pokoj3.h"
#include "ui_pokoj3.h"

Pokoj3::Pokoj3(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Pokoj3)
{
    ui->setupUi(this);
    setWindowTitle("Pokój 3");

    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R10_kontury_36-45.png");
    ui->pokoj->setPixmap(pix);
}

Pokoj3::~Pokoj3()
{
    delete ui;
}

void Pokoj3::on_wlaczTelewizor_clicked()
{

    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R07_telewizor_46-139.png");
    ui->telewizor->setPixmap(pix);
}

void Pokoj3::on_wylacztelewizor_clicked()
{
    QPixmap pix("");
    ui->telewizor->setPixmap(pix);
}

void Pokoj3::on_wlaczSwiatlo_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R01_swiatloPokoj_45-54.png");
    ui->swiatlo->setPixmap(pix);
}

void Pokoj3::on_wylaczSwiatlo_clicked()
{
    QPixmap pix("");
    ui->swiatlo->setPixmap(pix);
}

void Pokoj3::on_wlaczSwiatloLazienka_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R02_swiatloLazienka_175-374.png");
    ui->swiatloLazienka->setPixmap(pix);
}

void Pokoj3::on_otworzOkno_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R04_okno_136-46.png");
    ui->okno->setPixmap(pix);
}

void Pokoj3::on_wlaczGrzaniePokoj_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R05_kaloryferPokoj_140-55.png");
    ui->kaloryferPokoj->setPixmap(pix);
}

void Pokoj3::on_wlaczGrzanieLazienka_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R06_kaloryferLazienka_176-375.png");
    ui->kaloryferLazienka->setPixmap(pix);
}

void Pokoj3::on_zamknijDrzwi_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R03_drzwi_66-556.png");
    ui->drzwi->setPixmap(pix);
}

void Pokoj3::on_wlaczMuzyka_clicked()
{

}



void Pokoj3::on_wylaczSwiatloLazienka_clicked()
{
    QPixmap pix("");
    ui->swiatloLazienka->setPixmap(pix);
}

void Pokoj3::on_zamknijOkno_clicked()
{
    QPixmap pix("");
    ui->okno->setPixmap(pix);
}

void Pokoj3::on_wylaczGrzaniePokoj_clicked()
{
    QPixmap pix("");
    ui->kaloryferPokoj->setPixmap(pix);
}

void Pokoj3::on_wylaczGrzanieLazienka_clicked()
{
    QPixmap pix("");
    ui->kaloryferLazienka->setPixmap(pix);
}

void Pokoj3::on_otworzDrzwi_clicked()
{
    QPixmap pix("");
    ui->drzwi->setPixmap(pix);
}

void Pokoj3::on_wylaczMuzyka_clicked()
{

}
