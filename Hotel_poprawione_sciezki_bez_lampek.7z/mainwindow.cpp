#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Sterownia");
    // ui->pokoj1->hide();
    ui->pokoj2->hide();
    ui->pokoj3->hide();
    ui->pokoj4->hide();

     nowy1 = new Pokoj1;
     nowy2 = new Pokoj2;
     nowy3 = new Pokoj3;
     nowy4 = new Pokoj4;

     //Połączenia dla pokoju 1 ----------------------------------------------------------------------
     connect(this , SIGNAL(on_wlSwiatloLazienka_clicked()), nowy1 , SLOT(on_pushButton_3_clicked()));
     connect(this , SIGNAL(on_wylSwiatloLazienka_clicked()), nowy1 , SLOT(on_pushButton_8_clicked()));

     connect(this , SIGNAL(on_wlaczTelewizor_clicked()), nowy1 , SLOT(on_pushButton_clicked()));
     connect(this , SIGNAL(on_wylaczTelewizor_clicked()), nowy1 , SLOT(on_pushButton_9_clicked()));

     connect(this , SIGNAL(on_wlOgrzewanie_clicked()), nowy1 , SLOT(on_pushButton_5_clicked()));
     connect(this , SIGNAL(on_wylOgrzewanie_clicked()), nowy1 , SLOT(on_pushButton_12_clicked()));

     connect(this , SIGNAL(on_wlOgrzewanie_clicked()), nowy1 , SLOT(on_pushButton_6_clicked()));
     connect(this , SIGNAL(on_wylOgrzewanie_clicked()), nowy1 , SLOT(on_pushButton_13_clicked()));

     connect(this , SIGNAL(on_drzwiOtworz_clicked()), nowy1 , SLOT(on_pushButton_14_clicked()));
     connect(this , SIGNAL(on_drzwiZamknij_clicked()), nowy1 , SLOT(on_pushButton_7_clicked()));

     connect(this , SIGNAL(on_wlSwiatloGlowne_clicked()), nowy1 , SLOT(on_pushButton_2_clicked()));
     connect(this , SIGNAL(on_wylSwiatloGlowne_clicked()), nowy1 , SLOT(on_pushButton_10_clicked()));

     connect(this , SIGNAL(on_wlMuzyka_clicked()), nowy1 , SLOT(on_pushButton_15_clicked()));
     connect(this , SIGNAL(on_wylMuzyka_clicked()), nowy1 , SLOT(on_pushButton_16_clicked()));

     connect(this , SIGNAL(on_oknoOtworz_clicked()), nowy1 , SLOT(on_pushButton_4_clicked()));
     connect(this , SIGNAL(on_oknoZamknij_clicked()), nowy1 , SLOT(on_pushButton_11_clicked()));



     //---------------------------------------------------------------------------------------------

     //Połączenia dla pokoju 2 ----------------------------------------------------------------------

     connect(this , SIGNAL(on_wlSwiatloLazienka_2_clicked()), nowy2 , SLOT(on_wlaczSwiatloLazienka_clicked()));
     connect(this , SIGNAL(on_wylSwiatloLazienka_2_clicked()), nowy2 , SLOT(on_wylaczSwiatloLazienka_clicked()));

     connect(this , SIGNAL(on_wlaczTelewizor_2_clicked()), nowy2 , SLOT(on_wlaczTelewizor_clicked()));
     connect(this , SIGNAL(on_wylaczTelewizor_2_clicked()), nowy2 , SLOT(on_wylacztelewizor_clicked()));

     connect(this , SIGNAL(on_wlOgrzewanie_2_clicked()), nowy2 , SLOT(on_wlaczGrzaniePokoj_clicked()));
     connect(this , SIGNAL(on_wylOgrzewanie_2_clicked()), nowy2 , SLOT(on_wylaczGrzaniePokoj_clicked()));

     connect(this , SIGNAL(on_wlOgrzewanie_2_clicked()), nowy2 , SLOT(on_wlaczGrzanieLazienka_clicked()));
     connect(this , SIGNAL(on_wylOgrzewanie_2_clicked()), nowy2 , SLOT(on_wylaczGrzanieLazienka_clicked()));

     connect(this , SIGNAL(on_drzwiOtworz_2_clicked()), nowy2 , SLOT(on_otworzDrzwi_clicked()));
     connect(this , SIGNAL(on_drzwiZamknij_2_clicked()), nowy2 , SLOT(on_zamknijDrzwi_clicked()));

     connect(this , SIGNAL(on_wlSwiatloGlowne_2_clicked()), nowy2 , SLOT(on_wlaczSwiatlo_clicked()));
     connect(this , SIGNAL(on_wylSwiatloGlowne_2_clicked()), nowy2 , SLOT(on_wylaczSwiatlo_clicked()));

     connect(this , SIGNAL(on_wlMuzyka_2_clicked()), nowy2 , SLOT(on_wlaczMuzyka_clicked()));
     connect(this , SIGNAL(on_wylMuzyka_2_clicked()), nowy2 , SLOT(on_wylaczMuzyka_clicked()));

     connect(this , SIGNAL(on_oknoOtworz_2_clicked()), nowy2 , SLOT(on_otworzOkno_clicked()));
     connect(this , SIGNAL(on_zamknijOkno_2_clicked()), nowy2 , SLOT(on_zamknijOkno_clicked()));

     //---------------------------------------------------------------------------------------------

     //Połączenia dla pokoju 3 ----------------------------------------------------------------------
     connect(this , SIGNAL(on_wlSwiatloLazienka_3_clicked()), nowy3 , SLOT(on_wlaczSwiatloLazienka_clicked()));
     connect(this , SIGNAL(on_wylSwiatloLazienka_3_clicked()), nowy3 , SLOT(on_wylaczSwiatloLazienka_clicked()));

     connect(this , SIGNAL(on_wlaczTelewizor_3_clicked()), nowy3 , SLOT(on_wlaczTelewizor_clicked()));
     connect(this , SIGNAL(on_wylaczTelewizor_3_clicked()), nowy3 , SLOT(on_wylacztelewizor_clicked()));

     connect(this , SIGNAL(on_wlOgrzewanie_3_clicked()), nowy3 , SLOT(on_wlaczGrzaniePokoj_clicked()));
     connect(this , SIGNAL(on_wylOgrzewanie_3_clicked()), nowy3 , SLOT(on_wylaczGrzaniePokoj_clicked()));

     connect(this , SIGNAL(on_wlOgrzewanie_3_clicked()), nowy3 , SLOT(on_wlaczGrzanieLazienka_clicked()));
     connect(this , SIGNAL(on_wylOgrzewanie_3_clicked()), nowy3 , SLOT(on_wylaczGrzanieLazienka_clicked()));

     connect(this , SIGNAL(on_drzwiOtworz_3_clicked()), nowy3 , SLOT(on_otworzDrzwi_clicked()));
     connect(this , SIGNAL(on_drzwiZamknij_3_clicked()), nowy3 , SLOT(on_zamknijDrzwi_clicked()));

     connect(this , SIGNAL(on_wlSwiatloGlowne_3_clicked()), nowy3 , SLOT(on_wlaczSwiatlo_clicked()));
     connect(this , SIGNAL(on_wylSwiatloGlowne_3_clicked()), nowy3 , SLOT(on_wylaczSwiatlo_clicked()));

     connect(this , SIGNAL(on_wlMuzyka_3_clicked()), nowy3 , SLOT(on_wlaczMuzyka_clicked()));
     connect(this , SIGNAL(on_wylMuzyka_3_clicked()), nowy3 , SLOT(on_wylaczMuzyka_clicked()));

     connect(this , SIGNAL(on_otworzOkno_3_clicked()), nowy3 , SLOT(on_otworzOkno_clicked()));
     connect(this , SIGNAL(on_zamknijOkno_3_clicked()), nowy3 , SLOT(on_zamknijOkno_clicked()));



     //---------------------------------------------------------------------------------------------


     //Połączenia dla pokoju 4 ----------------------------------------------------------------------
     connect(this , SIGNAL(on_wlSwiatloLazienka_4_clicked()), nowy4 , SLOT(on_wlaczSwiatloLazienka_clicked()));
     connect(this , SIGNAL(on_wylSwiatloLazienka_4_clicked()), nowy4 , SLOT(on_wylaczSwiatloLazienka_clicked()));

     connect(this , SIGNAL(on_wlaczTelewizor_4_clicked()), nowy4 , SLOT(on_wlaczTelewizor_clicked()));
     connect(this , SIGNAL(on_wylacztelewizor_4_clicked()), nowy4 , SLOT(on_wylacztelewizor_clicked()));

     connect(this , SIGNAL(on_wlOgrzewanie_4_clicked()), nowy4 , SLOT(on_wlaczGrzaniePokoj_clicked()));
     connect(this , SIGNAL(on_wylOgrzewanie_4_clicked()), nowy4 , SLOT(on_wylaczGrzaniePokoj_clicked()));

     connect(this , SIGNAL(on_wlOgrzewanie_4_clicked()), nowy4 , SLOT(on_wlaczGrzanieLazienka_clicked()));
     connect(this , SIGNAL(on_wylOgrzewanie_4_clicked()), nowy4 , SLOT(on_wylaczGrzanieLazienka_clicked()));

     connect(this , SIGNAL(on_drzwiOtworz_4_clicked()), nowy4 , SLOT(on_otworzDrzwi_clicked()));
     connect(this , SIGNAL(on_drzwiZamknij_4_clicked()), nowy4 , SLOT(on_zamknijDrzwi_clicked()));

     connect(this , SIGNAL(on_wlSwiatloGlowne_4_clicked()), nowy4 , SLOT(on_wlaczSwiatlo_clicked()));
     connect(this , SIGNAL(on_wylSwiatloGlowne_4_clicked()), nowy4 , SLOT(on_wylaczSwiatlo_clicked()));

     connect(this , SIGNAL(on_wlMuzyka_4_clicked()), nowy4 , SLOT(on_wlaczMuzyka_clicked()));
     connect(this , SIGNAL(on_wylMuzyka_4_clicked()), nowy4 , SLOT(on_wylaczMuzyka_clicked()));

     connect(this , SIGNAL(on_otworzOkno_4_clicked()), nowy4 , SLOT(on_otworzOkno_clicked()));
     connect(this , SIGNAL(on_zamknijOkno_4_clicked()), nowy4 , SLOT(on_zamknijOkno_clicked()));



     //---------------------------------------------------------------------------------------------


}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_comboBox_currentIndexChanged(int index)
{
    switch(index)
    {
        case 0:
            ui->pokoj1->show();
            ui->pokoj2->hide();
            ui->pokoj3->hide();
            ui->pokoj4->hide();
        break;

        case 1:
            ui->pokoj2->show();
            ui->pokoj1->hide();
            ui->pokoj3->hide();
            ui->pokoj4->hide();
        break;

        case 2:
            ui->pokoj3->show();
            ui->pokoj1->hide();
            ui->pokoj2->hide();
            ui->pokoj4->hide();
        break;

        case 3:
            ui->pokoj4->show();
            ui->pokoj1->hide();
            ui->pokoj2->hide();
            ui->pokoj3->hide();
        break;
    }

}

void MainWindow::on_wyswietl_pokoj_clicked()
{
    switch( ui->comboBox->currentIndex() )
    {
        case 0:
            nowy1->show();
        break;

        case 1:
            nowy2->show();
        break;

        case 2:
            nowy3->show();
        break;

        case 3:
         nowy4->show();
        break;

    }

}

void MainWindow::on_pushButton_clicked()
{
       switch( ui->comboBox->currentIndex() )
       {
        case 0:
           nowy1->hide();
        break;

        case 1:
           nowy2->hide();
        break;

        case 2:
           nowy3->hide();
        break;

        case 3:
           nowy4->hide();
        break;
       }
}









