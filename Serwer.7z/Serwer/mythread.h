#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QObject>
#include <QThread>
#include <QtSerialPort/QSerialPort>
#include <QMutex>

class mythread : public QThread
{
    Q_OBJECT
public:
    explicit mythread(QObject *parent = nullptr);
    void run();
    bool sending;
    bool stop=false;


signals:
    void goo();

public slots:
};

#endif // MYTHREAD_H
