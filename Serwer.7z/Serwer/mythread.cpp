#include "mythread.h"
#include <QThread>
#include <QtCore>
#include <QMutex>
QMutex mutex;

mythread::mythread(QObject *parent) : QThread(parent)
{

}

void mythread::run()
{
    while(sending)
    {
        emit mythread::goo();
        QThread::sleep(1);

    }
}
