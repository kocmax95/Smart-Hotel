#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QtCore/QtGlobal>

#include <QMainWindow>
#include <QAction>
#include <QtSerialPort/QSerialPort>
#include "mythread.h"

namespace Ui {
class MainWindow;
}
class mythread;
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

    void after_reading();
    mythread *mThread;
    mythread *mt;
    QMutex *mm;



private:
    Ui::MainWindow *ui;
    QString s_temp , y1,y2,y3;
    QString mess;
    QByteArray s_change,r_data;
    int changes_tab[3];

    //void initActionsConnections();

    void send_changes(int param, int value);
    void message();

    QSerialPort *serial;

    bool Pietro1[7] ={false,false,false,false,false,false,false};
    bool Pietro2[7]={false,false,false,false,false,false,false};

private slots:
    void openSerialPort();

    void closeSerialPort();

    void writeData(const QByteArray &data);

    void always_sending();

    void readData();

    void handleError(QSerialPort::SerialPortError error);

    void on_wlaczTelewizor_clicked();

    void on_wylaczTelewizor_clicked();

    void on_wlaczSwiatlo_clicked();

    void on_wylaczSwiatlo_clicked();

    void on_wlaczSwiatloLazienka_clicked();

    void on_wylaczSwiatloLazienka_clicked();

    void on_kalLazienkaWlacz_clicked();

    void on_kalLazienkaWylacz_clicked();

    void on_kalPokojWlacz_clicked();

    void on_kalPokojWylacz_clicked();

    void on_zamknijDrzwi_clicked();

    void on_otworzDrzwi_clicked();

    void on_otworzOkno_clicked();

    void on_zamknijOkno_clicked();

    void on_czasPracy_clicked();

    void on_pokazRachunek_clicked();

    void aktualizujWidok();

    void on_pushButton_polacz_clicked();

    void on_pushButton_rozlacz_clicked();


};

#endif // MAINWINDOW_H
