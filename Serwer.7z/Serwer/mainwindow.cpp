#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDebug>
#include <QAction>
#include <QMessageBox>
#include <QtSerialPort/QSerialPort>
#include <QPixmap>
#include <mythread.h>



MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    serial=new QSerialPort(this);
    mm = new QMutex;

    mThread = new mythread(this);
    connect(mThread,SIGNAL(goo()),this,SLOT(always_sending()));


    connect(ui->pushButton_polacz,SIGNAL(triggered()),this,SLOT(openSerialPort()));
    connect(ui->pushButton_rozlacz,SIGNAL(triggered()),this,SLOT(closeSerialPort()));



   // connect(this, SIGNAL(on_pushButton_rozlacz_clicked()), this, SLOT(closeSerialPort()));
    connect(ui->ListaPokoi, SIGNAL(currentIndexChanged(QString)) , this , SLOT(aktualizujWidok()));

    connect(serial,SIGNAL(error(QSerialPort::SerialPortError)),this,
            SLOT(handleError(QSerialPort::SerialPortError)));

    connect(serial, SIGNAL(readyRead()), this, SLOT(readData()));



   // connect(serial,SIGNAL(readyRead()),this,SLOT(readData()));


    // connect(ui->actionQuit, SIGNAL(triggered()), this, SLOT(close()));
    //connect(ui->actionConfigure, SIGNAL(triggered()), settings, SLOT(show()));
  //  connect(ui->actionAbout, SIGNAL(triggered()), this, SLOT(about()));
  //  connect(ui->actionAboutQt, SIGNAL(triggered()), qApp, SLOT(aboutQt()));
}

/*void MainWindow::openSerialPort()
{
   // QString p;
   // p=ui->comboBox_2->currentText();
    serial->setPortName("COM5");
    serial->setBaudRate(QSerialPort::Baud9600);
        serial->setDataBits(QSerialPort::Data8);
        serial->setParity(QSerialPort::NoParity);
        serial->setStopBits(QSerialPort::OneStop);
        serial->setFlowControl(QSerialPort::NoFlowControl);
    if (serial->open(QIODevice::ReadWrite)) {
            ui->pushButton_polacz->setEnabled(false);
            ui->pushButton_rozlacz->setEnabled(true);
          //  ui->actionDisconnect->setEnabled(true);
           // ui->actionConfigure->setEnabled(false);
       //     ui->statusBar->showMessage(tr("Connected to %1 : %2, %3, %4, %5, %6")
           //                            .arg(p.name).arg(p.stringBaudRate).arg(p.stringDataBits)
           //                            .arg(p.stringParity).arg(p.stringStopBits).arg(p.stringFlowControl));
    } else {
        QMessageBox::critical(this, tr("Error"), serial->errorString());

        //ui->statusBar->showMessage(tr("Open error"));
    }
    //ui->statusBar->showMessage("Czekam na pokoje...");

}*/
void MainWindow::closeSerialPort()
{
    if (serial->isOpen())
        serial->close();

    ui->pushButton_polacz->setEnabled(true);
    ui->pushButton_rozlacz->setEnabled(false);
    mThread->sending=0;

   // ui->actionDisconnect->setEnabled(false);
    //ui->actionConfigure->setEnabled(true);

}
/*void MainWindow::initActionsConnections()
{

}*/
void MainWindow::readData()
{
   r_data.append(serial->readAll());
   after_reading();
}
void MainWindow::writeData(const QByteArray &data)
{
    serial->write(data);
}

void MainWindow::send_changes(int param,int value)
{
    QString p = ui->ListaPokoi->currentText();
    QString pokoj = p.at(7);


    s_temp.append(pokoj);
     s_temp.append(QString::number(param));
    s_temp.append(QString::number(value));

    s_change.append(s_temp);
    qDebug() << "Wysylam zmiane do pokoju: " << s_change;

    //writeData(s_change);
   // s_change.clear();
    s_temp.clear();



    /*  s_temp.append(QString::number(param));
    s_temp.append(' ');
    s_temp.append(QString::number(value));
    s_temp.append(' ');
    s_temp.append(';');
    s_change.append(s_temp);
    qDebug() << "Wysylam zmiane do pokoju: " << s_change;

    writeData(s_change);
    s_change.clear();
    s_temp.clear();*/
}
void MainWindow::always_sending()
{
    mm->lock();
    writeData(s_change);
    s_change.clear();
    mm->unlock();
}

void MainWindow::handleError(QSerialPort::SerialPortError error)
{
    if (error == QSerialPort::ResourceError) {
        QMessageBox::critical(this, tr("Critical Error"), serial->errorString());
        closeSerialPort();
    }
}






MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_wlaczTelewizor_clicked()
{
    send_changes(1,1);

}

void MainWindow::on_wylaczTelewizor_clicked()
{
    send_changes(1,0);

}

void MainWindow::on_wlaczSwiatlo_clicked()
{
    send_changes(2,1);

}

void MainWindow::on_wylaczSwiatlo_clicked()
{
    send_changes(2,0);

}

void MainWindow::on_wlaczSwiatloLazienka_clicked()
{
    send_changes(3,1);

}

void MainWindow::on_wylaczSwiatloLazienka_clicked()
{
    send_changes(3,0);

}

void MainWindow::on_kalLazienkaWlacz_clicked()
{
    send_changes(4,1);

}

void MainWindow::on_kalLazienkaWylacz_clicked()
{
    send_changes(4,0);

}

void MainWindow::on_kalPokojWlacz_clicked()
{
    send_changes(5,1);

}

void MainWindow::on_kalPokojWylacz_clicked()
{
    send_changes(5,0);

}

void MainWindow::on_zamknijDrzwi_clicked()
{
    send_changes(6,0);

}

void MainWindow::on_otworzDrzwi_clicked()
{
    send_changes(6,1);

}

void MainWindow::on_otworzOkno_clicked()
{
    send_changes(7,1);

}

void MainWindow::on_zamknijOkno_clicked()
{
    send_changes(7,0);

}

void MainWindow::on_czasPracy_clicked()
{
    send_changes(8,1);

}

void MainWindow::on_pokazRachunek_clicked()
{
    send_changes(9,1);
}


 void MainWindow::after_reading()
 {


     /*

     qDebug() << "Zawartosc bufora:" << r_data;

     QString temp(r_data);
     QString target;
     r_data.clear();


     if(temp.at(2)==8 || temp.at(2)==9)
     {
         y1 = temp.at(0);
         y2= temp.at(2);
         changes_tab[0] = y1.toInt();
         changes_tab[1] = y2.toInt();
         target = temp;
         target.remove(0,4);
         mess = target;

     }
     else

     {
     y1 = temp.at(0);
     y2= temp.at(2);
     y3 = temp.at(4);

     changes_tab[0] = y1.toInt();
     changes_tab[1] = y2.toInt();
     changes_tab[2] =  y3.toInt();
     }
   */
     QString temp(r_data);

if(temp.at(1)<"8")
{

     y1 = temp.at(0);
     y2= temp.at(1);
     y3 = temp.at(2);

     changes_tab[0] = y1.toInt();
     changes_tab[1] = y2.toInt();
     changes_tab[2] = y3.toInt();

     r_data.clear();
}
else if(temp.at(1)=="8" || temp.at(1)=='9')
{
    QString target;
    y1 = temp.at(0);
    y2= temp.at(1);
    changes_tab[0] = y1.toInt();
    changes_tab[1] = y2.toInt();
    target = temp;
    target.remove(0,2);
    mess = target;

}




     message();

 }

 void MainWindow::message()
 {

     QString message;
    // mess.clear();



     //-----------------------------Piętro 1------------------------------------------------------------
     if(changes_tab[0]==1)
     {
         message.append("Pietro1");

         switch(changes_tab[1])
         {
           case 1:
             message.append("Telewizor");
              switch(changes_tab[2])
              {
                    case 0:
                        message.append("Wyłączony");
                        Pietro1[0]=false;
                  break;
                    case 1:
                     message.append("Włączony");
                     Pietro1[0]=true;
                  break;


              }
             break;

         case 2:
           message.append("Światło główne");
            switch(changes_tab[2])
            {
                  case 0:
                      message.append("Wyłączony");
                      Pietro1[1]=false;
                break;
                  case 1:
                   message.append("Włączony");
                   Pietro1[1]=true;
                break;


            }
           break;

         case 3:
           message.append("Światło łazienka");
            switch(changes_tab[2])
            {
                  case 0:
                      message.append("Wyłączony");
                      Pietro1[2]=false;
                break;
                  case 1:
                   message.append("Włączony");
                   Pietro1[2]=true;
                break;
            }
             break;
            case 4:
              message.append("Kaloryfer łazienka");
               switch(changes_tab[2])
               {
                     case 0:
                         message.append("Wyłączony");
                         Pietro1[3]=false;
                   break;
                     case 1:
                      message.append("Włączony");
                      Pietro1[3]=true;
                   break;


               }
              break;

            case 5:
              message.append("Kaloryfer pokój");
               switch(changes_tab[2])
               {
                     case 0:
                         message.append("Wyłączony");
                         Pietro1[4]=false;
                   break;
                     case 1:
                      message.append("Włączony");
                      Pietro1[4]=true;
                   break;


               }
              break;

            case 6:
              message.append("Drzwi");
               switch(changes_tab[2])
               {
                     case 0:
                         message.append("Otwarte");
                         Pietro1[5]=false;
                   break;
                     case 1:
                      message.append("Zamknięte");
                      Pietro1[5]=true;
                   break;


               }
              break;

            case 7:
              message.append("Okno");
               switch(changes_tab[2])
               {
                     case 0:
                         message.append("Zamknięte");
                         Pietro1[6]=false;
                   break;
                     case 1:
                      message.append("Otwarte");
                      Pietro1[6]=true;
                   break;


               }
              break;


            case 8:
              //message.clear();
              message.append("Czas_dzialania:");
              message.append(mess);

              break;

            case 9:
                //message.clear();
                message.append("Rachunek_wynosi:");
                message.append(mess);
              break;

            default:
                 message.append("abcs");
                    break;
         }



         }

  //-----------------------------Piętro 2------------------------------------------------------------
     else if(changes_tab[0]==2)
     {
         message.append("Pietro2");

         switch(changes_tab[1])
         {
           case 1:
             message.append("Telewizor");
              switch(changes_tab[2])
              {
                    case 0:
                        message.append("Wyłączony");
                        Pietro2[0]=false;
                  break;
                    case 1:
                     message.append("Włączony");
                     Pietro2[0]=true;
                  break;


              }
             break;

         case 2:
           message.append("Światło główne");
            switch(changes_tab[2])
            {
                  case 0:
                      message.append("Wyłączony");
                      Pietro2[1]=false;
                break;
                  case 1:
                   message.append("Włączony");
                   Pietro2[1]=true;
                break;


            }
           break;

         case 3:
           message.append("Światło łazienka");
            switch(changes_tab[2])
            {
                  case 0:
                      message.append("Wyłączony");
                      Pietro2[2]=false;
                break;
                  case 1:
                   message.append("Włączony");
                   Pietro2[2]=true;
                break;

            case 4:
              message.append("Kaloryfer łazienka");
               switch(changes_tab[2])
               {
                     case 0:
                         message.append("Wyłączony");
                         Pietro2[3]=false;
                   break;
                     case 1:
                      message.append("Włączony");
                      Pietro2[3]=true;
                   break;


               }
              break;

            case 5:
              message.append("Kaloryfer pokój");
               switch(changes_tab[2])
               {
                     case 0:
                         message.append("Wyłączony");
                         Pietro2[4]=false;
                   break;
                     case 1:
                      message.append("Włączony");
                      Pietro2[4]=true;
                   break;


               }
              break;

            case 6:
              message.append("Drzwi");
               switch(changes_tab[2])
               {
                     case 0:
                         message.append("Otwarte");
                         Pietro2[5]=false;
                   break;
                     case 1:
                      message.append("Zamknięte");
                      Pietro2[5]=true;
                   break;


               }
              break;

            case 7:
              message.append("Okno");
               switch(changes_tab[2])
               {
                     case 0:
                         message.append("Zamknięte");
                         Pietro2[6]=false;
                   break;
                     case 1:
                      message.append("Otwarte");
                      Pietro2[6]=true;
                   break;


               }
              break;


            case 8:
              message.clear();

              message.append(mess);

              break;

            case 9:
                message.clear();

                message.append(mess);
              break;
            }
           break;


         }
     }



    mess.clear();
     aktualizujWidok();
     ui->odpowiedz->setText(message);

}
void MainWindow::on_pushButton_rozlacz_clicked()
{

}
void MainWindow::on_pushButton_polacz_clicked()
{
    QString p;
    p=ui->Com->currentText();
    serial->setPortName(p);
    serial->setBaudRate(QSerialPort::Baud9600);
        serial->setDataBits(QSerialPort::Data8);
        serial->setParity(QSerialPort::NoParity);
        serial->setStopBits(QSerialPort::OneStop);
        serial->setFlowControl(QSerialPort::NoFlowControl);
    if (serial->open(QIODevice::ReadWrite)) {
           // ui->pushButton_polacz->setEnabled(false);
    } else {
        QMessageBox::critical(this, tr("Error"), serial->errorString());
    }
    mThread->sending=1;
    mThread->start();
    //ui->Com->setEnabled(true);



}
void MainWindow::aktualizujWidok()
{
    if( (ui->ListaPokoi->currentText())== "Piętro 1")
    {
        if(Pietro1[0])
        {QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R07_telewizor_46-139.png");
          ui->telewizor->setPixmap(pix);
          ui->wlaczTelewizor->setEnabled(false);
          ui->wylaczTelewizor->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->telewizor->setPixmap(pix2);
            ui->wlaczTelewizor->setEnabled(true);
            ui->wylaczTelewizor->setEnabled(false);
        }


        //-----------------------------

        if(Pietro1[1])
        {
            QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R01_swiatloPokoj_45-54.png");
            ui->swiatlo->setPixmap(pix);
            ui->wlaczSwiatlo->setEnabled(false);
            ui->wylaczSwiatlo->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->swiatlo->setPixmap(pix2);
            ui->wlaczSwiatlo->setEnabled(true);
            ui->wylaczSwiatlo->setEnabled(false);
        }

        //------------------------------

        if(Pietro1[2])
        {
            QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R02_swiatloLazienka_175-374.png");
            ui->swiatloLazienka->setPixmap(pix);
            ui->wlaczSwiatloLazienka->setEnabled(false);
            ui->wylaczSwiatloLazienka->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->swiatloLazienka->setPixmap(pix2);
            ui->wlaczSwiatloLazienka->setEnabled(true);
            ui->wylaczSwiatloLazienka->setEnabled(false);
        }

        //------------------------------

        if(Pietro1[3])
        {
            QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R06_kaloryferLazienka_176-375.png");
            ui->kaloryferLazienka->setPixmap(pix);
            ui->kalLazienkaWlacz->setEnabled(false);
            ui->kalLazienkaWylacz->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->kaloryferLazienka->setPixmap(pix2);
            ui->kalLazienkaWlacz->setEnabled(true);
            ui->kalLazienkaWylacz->setEnabled(false);
        }

        //------------------------------

        if(Pietro1[4])
        {
            QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R05_kaloryferPokoj_140-55.png");
            ui->kaloryferPokoj->setPixmap(pix);
            ui->kalPokojWlacz->setEnabled(false);
            ui->kalPokojWylacz->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->kaloryferPokoj->setPixmap(pix2);
            ui->kalPokojWlacz->setEnabled(true);
            ui->kalPokojWylacz->setEnabled(false);
        }

        //------------------------------

        if(Pietro1[5])
        {
            QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R03_drzwi_66-556.png");
            ui->drzwi->setPixmap(pix);
            ui->otworzDrzwi->setEnabled(false);
            ui->zamknijDrzwi->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->drzwi->setPixmap(pix2);
            ui->otworzDrzwi->setEnabled(true);
            ui->zamknijDrzwi->setEnabled(false);
        }

        //------------------------------

        if(Pietro1[6])
        {
            QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R04_okno_136-46.png");
            ui->okno->setPixmap(pix);
            ui->otworzOkno->setEnabled(false);
            ui->zamknijOkno->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->okno->setPixmap(pix2);
            ui->otworzOkno->setEnabled(true);
            ui->zamknijOkno->setEnabled(false);
        }




    //-----------------------------------------------------------------------------------------------------
    //-----------------------------------------------------------------------------------------------------
    }

    else if( (ui->ListaPokoi->currentText())== "Piętro 2" )
    {
        if(Pietro2[0])
        {QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R07_telewizor_46-139.png");
          ui->telewizor->setPixmap(pix);
          ui->wlaczTelewizor->setEnabled(false);
          ui->wylaczTelewizor->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->telewizor->setPixmap(pix2);
            ui->wlaczTelewizor->setEnabled(true);
            ui->wylaczTelewizor->setEnabled(false);
        }


        //-----------------------------

        if(Pietro2[1])
        {
            QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R01_swiatloPokoj_45-54.png");
            ui->swiatlo->setPixmap(pix);
            ui->wlaczSwiatlo->setEnabled(false);
            ui->wylaczSwiatlo->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->swiatlo->setPixmap(pix2);
            ui->wlaczSwiatlo->setEnabled(true);
            ui->wylaczSwiatlo->setEnabled(false);
        }

        //------------------------------

        if(Pietro2[2])
        {
            QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R02_swiatloLazienka_175-374.png");
            ui->swiatloLazienka->setPixmap(pix);
            ui->wlaczSwiatloLazienka->setEnabled(false);
            ui->wylaczSwiatloLazienka->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->swiatloLazienka->setPixmap(pix2);
            ui->wlaczSwiatloLazienka->setEnabled(true);
            ui->wylaczSwiatloLazienka->setEnabled(false);
        }

        //------------------------------

        if(Pietro2[3])
        {
            QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R06_kaloryferLazienka_176-375.png");
            ui->kaloryferLazienka->setPixmap(pix);
            ui->kalLazienkaWlacz->setEnabled(false);
            ui->kalLazienkaWylacz->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->kaloryferLazienka->setPixmap(pix2);
            ui->kalLazienkaWlacz->setEnabled(true);
            ui->kalLazienkaWylacz->setEnabled(false);
        }

        //------------------------------

        if(Pietro2[4])
        {
            QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R05_kaloryferPokoj_140-55.png");
            ui->kaloryferPokoj->setPixmap(pix);
            ui->kalPokojWlacz->setEnabled(false);
            ui->kalPokojWylacz->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->kaloryferPokoj->setPixmap(pix2);
            ui->kalPokojWlacz->setEnabled(true);
            ui->kalPokojWylacz->setEnabled(false);
        }

        //------------------------------

        if(Pietro2[5])
        {
            QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R03_drzwi_66-556.png");
            ui->drzwi->setPixmap(pix);
            ui->otworzDrzwi->setEnabled(false);
            ui->zamknijDrzwi->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->drzwi->setPixmap(pix2);
            ui->otworzDrzwi->setEnabled(true);
            ui->zamknijDrzwi->setEnabled(false);

        }

        //------------------------------

        if(Pietro2[6])
        {
            QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R04_okno_136-46.png");
            ui->okno->setPixmap(pix);
            ui->otworzOkno->setEnabled(false);
            ui->zamknijOkno->setEnabled(true);
        }
        else
        {
            QPixmap pix2("");
            ui->okno->setPixmap(pix2);
            ui->otworzOkno->setEnabled(true);
            ui->zamknijOkno->setEnabled(false);
        }


    }
}
