#include "dialog.h"
#include "ui_dialog.h"
#include <QTime>
#include <QDebug>
#include <QAction>
#include <QMessageBox>
#include <QtSerialPort/QSerialPort>
#include <mythread.h>

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);

    serial = new QSerialPort(this);

    mm=new QMutex;


    mThread= new MyThread(this);
    connect(mThread,SIGNAL(NumberChanged(int)),this,SLOT(onNumberChanged(int)));
   // connect(mThread,SIGNAL(goo()),this,SLOT(sendChanges(int,int)));

    mThread1 = new MyThread1(this);
    connect(mThread1,SIGNAL(NumberChanged(int)),this,SLOT(onNumberChanged2(int)));
     //connect(mThread1,SIGNAL(goo()),this,SLOT(sendChanges(int,int)));

    mThread2 = new MyThread2(this);
    connect(mThread2,SIGNAL(goo()),this,SLOT(always_sending()));








    mThread->start();
     mThread1->start();
      //mThread2->start();

      QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R10_kontury_36-45.png");
      ui->pokoj->setPixmap(pix);

      connect(ui->pushButtonPolacz,SIGNAL(triggered()),this,SLOT(openSerialPort()));
      connect(ui->pushButtonRozlacz,SIGNAL(triggered()),this,SLOT(closeSerialPort()));

      connect(serial, SIGNAL(error(QSerialPort::SerialPortError)), this,
              SLOT(handleError(QSerialPort::SerialPortError)));

      connect(serial, SIGNAL(readyRead()), this, SLOT(read()));

  }

Dialog::~Dialog()
{
    delete ui;
}


/*void Dialog::openSerialPort()
{
   QString p;
   p="COM6";
   serial->setPortName(p);
    serial->setBaudRate(QSerialPort::Baud9600);
        serial->setDataBits(QSerialPort::Data8);
        serial->setParity(QSerialPort::NoParity);
        serial->setStopBits(QSerialPort::OneStop);
        serial->setFlowControl(QSerialPort::NoFlowControl);
    if (serial->open(QIODevice::ReadWrite)) {
            ui->pushButtonPolacz->setEnabled(false);
            ui->pushButtonRozlacz->setEnabled(true);
          //  ui->actionDisconnect->setEnabled(true);
           // ui->actionConfigure->setEnabled(false);
       //     ui->statusBar->showMessage(tr("Connected to %1 : %2, %3, %4, %5, %6")
           //                            .arg(p.name).arg(p.stringBaudRate).arg(p.stringDataBits)
           //                            .arg(p.stringParity).arg(p.stringStopBits).arg(p.stringFlowControl));
    } else {
        QMessageBox::critical(this, tr("Error"), serial->errorString());

        //ui->statusBar->showMessage(tr("Open error"));
    }
    //ui->statusBar->showMessage("Czekam na pokoje...");

}*/

void Dialog::closeSerialPort()
{
    if (serial->isOpen())
        serial->close();

    ui->pushButtonPolacz->setEnabled(true);
    ui->pushButtonRozlacz->setEnabled(false);
    mThread2->sending=0;
   // ui->actionDisconnect->setEnabled(false);
    //ui->actionConfigure->setEnabled(true);

}



void Dialog::handleError(QSerialPort::SerialPortError error)
{
    if (error == QSerialPort::ResourceError) {
        QMessageBox::critical(this, tr("Critical Error"), serial->errorString());
        closeSerialPort();
    }
}

void Dialog::onNumberChanged(int Number)
{
for(int i=0 ; i<5 ; i++)
{
    if(czyWlaczone[i])
    {
        calkowityCzas+=0.125;
        czasUrzadzen[i]+=0.125;
    }
    ui->label_2->setText(QString::number(calkowityCzas,'f',2));

    ui->czasTelewizor->setText(QString::number(czasUrzadzen[0],'f',2));
    ui->czasSwiatlo->setText(QString::number(czasUrzadzen[1],'f',2));
    ui->czasSwiatloLazienka->setText(QString::number(czasUrzadzen[2],'f',2));
    ui->czasKalPokoj->setText(QString::number(czasUrzadzen[3],'f',2));
    ui->czasKalLazienka->setText(QString::number(czasUrzadzen[4],'f',2));

}

}

void Dialog::onNumberChanged2(int Number)
{

    calkowityRachunek=calkowityCzas* 0.39;
    ui->label_4->setText(QString::number(calkowityRachunek,'f',2));

}

void Dialog::onNumberChanged3(int Number)
{



}



void Dialog::on_telewizorOn_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R07_telewizor_46-139.png");
    ui->telewizor->setPixmap(pix);
    czyWlaczone[0]=true;
    ui->telewizorOn->setEnabled(false);
    ui->telewizorOff->setEnabled(true);
    sendChanges(1,1);



}

void Dialog::on_zamknijDrzwi_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R03_drzwi_66-556.png");
    ui->drzwi->setPixmap(pix);
    ui->zamknijDrzwi->setEnabled(false);
    ui->otworzDrzwi->setEnabled(true);
    sendChanges(6,1);
}

void Dialog::on_telewizorOff_clicked()
{
    QPixmap pix("");
    ui->telewizor->setPixmap(pix);
    czyWlaczone[0]=false;
    ui->telewizorOn->setEnabled(true);
    ui->telewizorOff->setEnabled(false);
    sendChanges(1,0);
    //mThread2->sending=1;

}

void Dialog::on_swiatloOn_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R01_swiatloPokoj_45-54.png");
    ui->swiatlo->setPixmap(pix);
    czyWlaczone[1]=true;
    ui->swiatloOn->setEnabled(false);
    ui->swiatloOff->setEnabled(true);
    sendChanges(2,1);
}

void Dialog::on_swiatloOff_clicked()
{
    QPixmap pix("");
    ui->swiatlo->setPixmap(pix);
    czyWlaczone[1]=false;
    ui->swiatloOn->setEnabled(true);
    ui->swiatloOff->setEnabled(false);
    sendChanges(2,0);
}

void Dialog::on_swiatloLazienkaOn_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R02_swiatloLazienka_175-374.png");
    ui->swiatloLazienka->setPixmap(pix);
    czyWlaczone[2]=true;
    ui->swiatloLazienkaOn->setEnabled(false);
    ui->swiatloLazienkaOff->setEnabled(true);
    sendChanges(3,1);
}

void Dialog::on_swiatloLazienkaOff_clicked()
{
    QPixmap pix("");
    ui->swiatloLazienka->setPixmap(pix);
    czyWlaczone[2]=false;
    ui->swiatloLazienkaOn->setEnabled(true);
    ui->swiatloLazienkaOff->setEnabled(false);
    sendChanges(3,0);
}

void Dialog::on_otworzOkno_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R04_okno_136-46.png");
    ui->okno->setPixmap(pix);
    ui->otworzOkno->setEnabled(false);
    ui->zamknijOkno->setEnabled(true);
    sendChanges(7,1);
}

void Dialog::on_zamknijOkno_clicked()
{
    QPixmap pix("");
    ui->okno->setPixmap(pix);
    ui->otworzOkno->setEnabled(true);
    ui->zamknijOkno->setEnabled(false);
    sendChanges(7,0);
}

void Dialog::on_kaloryferPokojOn_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R05_kaloryferPokoj_140-55.png");
    ui->kaloryferPokoj->setPixmap(pix);
    czyWlaczone[3]=true;
    ui->kaloryferPokojOn->setEnabled(false);
    ui->kaloryferPokojOff->setEnabled(true);
    sendChanges(5,1);
}

void Dialog::on_kaloryferPokojOff_clicked()
{
    QPixmap pix("");
    ui->kaloryferPokoj->setPixmap(pix);
    czyWlaczone[3]=false;
    ui->kaloryferPokojOn->setEnabled(true);
    ui->kaloryferPokojOff->setEnabled(false);
    sendChanges(5,0);
}

void Dialog::on_kaloryferLazienkaOn_clicked()
{
    QPixmap pix(":/Obrazy_2/Obrazy/Projekt-Hotel-PNG(1)/R06_kaloryferLazienka_176-375.png");
    ui->kaloryferLazienka->setPixmap(pix);
    czyWlaczone[4]=true;
    ui->kaloryferLazienkaOn->setEnabled(false);
    ui->kaloryferLazienkaOff->setEnabled(true);
    sendChanges(4,1);
}

void Dialog::on_kaloryferLazienkaOff_clicked()
{
    QPixmap pix("");
    ui->kaloryferLazienka->setPixmap(pix);
    czyWlaczone[4]=false;
    ui->kaloryferLazienkaOn->setEnabled(true);
    ui->kaloryferLazienkaOff->setEnabled(false);
    sendChanges(4,0);
}

void Dialog::on_otworzDrzwi_clicked()
{
    QPixmap pix("");
    ui->drzwi->setPixmap(pix);
    ui->zamknijDrzwi->setEnabled(true);
    ui->otworzDrzwi->setEnabled(false);
    sendChanges(6,0);
}


void Dialog::read()
{
    r_data.append(serial->readAll());
    after_read();


}

void Dialog::after_read()
{
    QString temp(r_data);

    //if(temp.at(0)=="1")
   // {
        y1 = temp.at(1);
        y2 = temp.at(2);

        changes_tab[0]= y1.toInt();
        changes_tab[1] = y2.toInt();

        r_data.clear();
        //qDebug()<<"xd";
        display();
  //  }



}

void Dialog::display()
{

    switch(changes_tab[0])
        {
          case 1:
             if(changes_tab[1]==0)
             {
                 on_telewizorOff_clicked();
                 //sendChanges(1,0);
             }
             else if(changes_tab[1]==1)
             {
                 on_telewizorOn_clicked();
                 //sendChanges(1,1);
             }

            break;

        case 2:
           if(changes_tab[1]==0)
           {
               on_swiatloOff_clicked();
               //sendChanges(2,0);
           }
           else
           {
               on_swiatloOn_clicked();
               //sendChanges(2,1);
           }
          break;

        case 3:
           if(changes_tab[1]==0)
           {
               on_swiatloLazienkaOff_clicked();
               //sendChanges(3,0);
           }
           else
              {
               on_swiatloLazienkaOn_clicked();
               //sendChanges(3,1);
           }
          break;

        case 4:
           if(changes_tab[1]==0)
           {
               on_kaloryferLazienkaOff_clicked();
               //sendChanges(4,0);
           }
           else
              {
               on_kaloryferLazienkaOn_clicked();
               //sendChanges(4,1);
           }
          break;

        case 5:
           if(changes_tab[1]==0)

           {on_kaloryferPokojOff_clicked();
               //sendChanges(5,0);
           }
           else
              {
               on_kaloryferPokojOn_clicked();
               //sendChanges(5,1);
           }
          break;

        case 6:
           if(changes_tab[1]==0)
           {
               on_otworzDrzwi_clicked();
               //sendChanges(6,0);
           }
           else
           {
               on_zamknijDrzwi_clicked();
               //sendChanges(6,1);
           }
          break;

        case 7:
           if(changes_tab[1]==0)
              {
               on_zamknijOkno_clicked();
               //sendChanges(7,0);
           }
           else
           {
               on_otworzOkno_clicked();
               //sendChanges(7,1);
           }
          break;

        case 8:
           sendChanges(8,1);
          break;

        case 9:
           sendChanges(9,1);
          break;

        }
}

void Dialog::sendChanges(int p1 , int p2)
{
    QString message;

    s_temp.append('1');
    s_temp.append(QString::number(p1));

    if(p2 == 8)
    {
        message = ui->label_2->text();
        s_temp.append(message);
    }


     else if(p2==9)
    {
        message = ui->label_4->text();
        s_temp.append(message);
    }

    else
    {
        s_temp.append(QString::number(p2));
    }

    s_data.append(s_temp);

    s_temp.clear();


    //write_Data(s_data);

    //s_temp.clear();
    //s_data.clear();


}

void Dialog::always_sending()
{
    mm->lock();
    write_Data(s_data);
    s_data.clear();
    mm->unlock();
}

void Dialog::write_Data(const QByteArray &data)
{
    serial->write(data);
}

void Dialog::on_pushButtonPolacz_clicked()
{
    QString p;
    p=ui->COM->currentText();
    serial->setPortName(p);
    serial->setBaudRate(QSerialPort::Baud9600);
        serial->setDataBits(QSerialPort::Data8);
        serial->setParity(QSerialPort::NoParity);
        serial->setStopBits(QSerialPort::OneStop);
        serial->setFlowControl(QSerialPort::NoFlowControl);
    if (serial->open(QIODevice::ReadWrite)) {
           // ui->pushButtonPolacz->setEnabled(false);
    } else {
        QMessageBox::critical(this, tr("Error"), serial->errorString());
    }
    mThread2->sending=1;
    mThread2->start();
    //ui->COM->setEnabled(true);
}
