#ifndef MYTHREAD_H
#define MYTHREAD_H

#include <QThread>
#include <QtSerialPort/QSerialPort>


class MyThread : public QThread
{
    Q_OBJECT
public:
    explicit MyThread(QObject *parent = 0);
    void run();
    //bool sending;
    bool stop=false;
signals:
    void NumberChanged(int);
    void NumberChanged2(int);
   // void goo();

public slots:


};
class MyThread1 : public QThread
{
    Q_OBJECT
public:
    explicit MyThread1(QObject *parent = 0);
    void run();
   // bool sending;
    bool stop=false;
signals:
    void NumberChanged(int);
    void NumberChanged2(int);
   // void goo();

public slots:


};
class MyThread2 : public QThread
{
    Q_OBJECT
public:
    explicit MyThread2(QObject *parent = 0);
    void run();
    bool stop=false;
    bool sending;
signals:
    void NumberChanged(int);
    void goo();


public slots:


};

#endif // MYTHREAD_H
