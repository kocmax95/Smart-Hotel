#ifndef DIALOG_H
#define DIALOG_H

#include "mythread.h"

#include <QtSerialPort/QSerialPort>
#include <QMessageBox>

#include <QDialog>
#include <QMutex>

namespace Ui {
class Dialog;
}
class mythread;
class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();
    MyThread *mThread;
    MyThread1 *mThread1;
    MyThread2 *mThread2;



    bool czyWlaczone[5]={false,false,false,false,false};
    float czasUrzadzen[5]={0,0,0,0,0};
    float calkowityCzas=0;
    float calkowityRachunek=0;

    mythread *mt;
    QMutex *mm;


private:
    Ui::Dialog *ui;

    int changes_tab[3];
    void after_read();
    void display();

    void write_Data(const QByteArray &data);
    QByteArray r_data , s_data;
    QString y1,y2,  s_temp;

    QSerialPort* serial;




signals:
    void NumberChanged(int);
    //void on_pushButtonPolacz_clicked();
   // void on_pushButtonRozlacz_clicked();



public slots:
    void onNumberChanged(int);
    void onNumberChanged2(int);
    void onNumberChanged3(int);
    void read();
     void sendChanges(int p1 , int p2 );

private slots:
    void openSerialPort();
    void closeSerialPort();
    void handleError(QSerialPort::SerialPortError error);


    void on_telewizorOn_clicked();
    void on_otworzDrzwi_clicked();
    void on_telewizorOff_clicked();
    void on_swiatloOn_clicked();
    void on_swiatloOff_clicked();
    void on_swiatloLazienkaOn_clicked();
    void on_swiatloLazienkaOff_clicked();
    void on_otworzOkno_clicked();
    void on_zamknijOkno_clicked();
    void on_kaloryferPokojOn_clicked();
    void on_kaloryferPokojOff_clicked();
    void on_kaloryferLazienkaOn_clicked();
    void on_kaloryferLazienkaOff_clicked();
    void on_zamknijDrzwi_clicked();
    void on_pushButtonRozlacz_clicked();
    void on_pushButtonPolacz_clicked();
    void always_sending();

   };


#endif // DIALOG_H
