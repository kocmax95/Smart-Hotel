#include "mythread.h"
#include <QtCore>
#include <QThread>
#include <QMutex>
QMutex mutex;
MyThread::MyThread(QObject *parent) : QThread(parent)
{

}
MyThread1::MyThread1(QObject *parent) : QThread(parent)
{

}
MyThread2::MyThread2(QObject *parent)
{

}

void MyThread::run()
{
    for (int i=0;;)
    {
        mutex.lock();
        if(this->stop) break;
        mutex.unlock();


        emit NumberChanged(i);
        emit NumberChanged2(i);
        i++;

        this->msleep(125);

    }
}

void MyThread1::run()
{
    for (int i=0;;)
    {
        mutex.lock();
        if(this->stop) break;
        mutex.unlock();

        emit NumberChanged(i);
        emit NumberChanged2(i);
        i++;

        this->msleep(1000);

    }
}

void MyThread2::run()
{
    while(sending)
    {
        emit MyThread2::goo();
        QThread::sleep(1);
    }
}
